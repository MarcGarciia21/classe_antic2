<?php
class AulasModel
{
    protected $db;
 
    public function __construct()
    {
        //Traemos la única instancia de PDO
        $this->db = SPDO::singleton();
    }
 
    public function listadoTotal()
    {
        //realizamos la consulta de todos los aulas
        $consulta = $this->db->prepare('SELECT * FROM tb_aulas');
        $consulta->execute();
        //devolvemos la colección para que la vista la presente.
        return $consulta;
    }

    public function datos_formulario($id)
    {
        //realizamos la consulta de todos los aulas
        $consulta = $this->db->prepare("SELECT * FROM tb_aulas WHERE id_aula = $id");
        $consulta->setFetchMode(PDO::FETCH_ASSOC);
        $consulta->execute();
        //devolvemos la colección para que la vista la presente.
        return $consulta;
    }

    public function gravar_modificacio($request)
    {
        //realizamos la consulta de todos los aulas
        ?>
        <td><a href="index.php?controlador=Aulas&accion=listar"><img src="botones/atras.png" width="30px" height="30px"></a></td>
       <?php
        
        $consulta = $this->db->prepare("UPDATE tb_aulas SET aula='".$request["aula"]."' WHERE id_aula=".$request["id_aula"]);
        $consulta->setFetchMode(PDO::FETCH_ASSOC);
        $consulta->execute();
        //devolvemos la colección para que la vista la presente.
        return $consulta;
      
    }
    


public function gravar_insercio($request)
{
    // realizamos la inserción del aula en la base de datos
    $consulta = $this->db->prepare("INSERT INTO tb_aulas (aula) VALUES (:aula)");
    $consulta->bindParam(':aula', $request["aula"]);
    $consulta->execute();
    
    // devolvemos el ID de la última fila insertada para mostrarlo en la vista
    return $this->db->lastInsertId();
}

    

    public function eliminar($id){
        ?>
        <td><a href="index.php?controlador=Aulas&accion=listar"><img src="botones/atras.png" width="30px" height="30px"></a></td>
        <p>Dades eliminades</p>
        <?php
        $consulta = $this->db->prepare("DELETE FROM tb_aulas WHERE id_aula=$id");
        $consulta->setFetchMode(PDO::FETCH_ASSOC);
        $consulta->execute();
    }

    public function afegir($request)
    {
        //realizamos la consulta de todos los aulas
        ?>
        <td><a href="index.php?controlador=Aulas&accion=listar"><img src="botones/atras.png" width="30px" height="30px"></a></td>
       <?php
        
        $consulta = $this->db->prepare("UPDATE tb_aulas SET aula='".$request["aula"]."' WHERE id_aula=".$request["id_aula"]);
        $consulta->setFetchMode(PDO::FETCH_ASSOC);
        $consulta->execute();
        //devolvemos la colección para que la vista la presente.
        return $consulta;
      
    }
    
    
}
?> 






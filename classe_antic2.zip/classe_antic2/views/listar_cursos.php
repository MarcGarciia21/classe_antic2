<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>MVC - Modelo, Vista, Controlador - Jourmoly</title>
</head>
<style> 
    table {
        width:1000px;
        font:normal 16px Arial;
        text-align:center;
        border-collapse:collapse;
        
        
    }
    table th {
        font:bold 17px Arial;
        background-color:lightblue;

       
    }

    .añadir{
        margin-left: 869px;
        margin-top: -30px;
    }
    table tr:nth-child(2n+1) {
    background-color: lightblue;
    }
    table tr:nth-child(2n+2) {
    background-color: white;
    }
    h1{
        margin-left: 500px;
    }

    </style>
     <td><a href="index.html"><img src="botones/atras.png" width="30px" height="30px"></a></td>
<body>

<h1>CRUD Cursos</h1>
<table>
    <tr>
        <th>ID</th>
        <th>Cursos</th>
        <th>Editar</th>
        <th>Eliminar</th>
        <th>Añadir</th>
    </tr>
    <?php
     // $listado es una variable asignada desde el controlador CursosController.
    while($cursos = $listado->fetch())
    {
    ?>
    <tr>
        <td><?php echo $cursos['id_cursos']?></td>
        <td><?php echo $cursos['curs']?></td>
        <td><a href="index.php?controlador=Cursos&accion=formulario_modificar&param=<?php echo $cursos["id_cursos"] ?>"><img src="botones/editar.jpeg"  width="30px" height="30px"></a></td>
        <td><a href="index.php?controlador=Cursos&accion=eliminar&param=<?php echo $cursos["id_cursos"] ?>"><img src="botones/papelera.jpeg"  width="50px" height="30px"></a></td>
    </tr>
    <?php
    }
    ?>
</table>
<div class="añadir">
<td><a href="index.php?controlador=Cursos&accion=afegir&param=<?php echo $cursos["id_curs"] ?>"><img src="botones/añadir1.png" width="30px" height="30px"></a></td>
</div>
</body>
</html>
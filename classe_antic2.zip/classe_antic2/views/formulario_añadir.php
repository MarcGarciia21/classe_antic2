<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>MVC - Modelo, Vista, Controlador - Jourmoly</title>
</head>
<body>
<form action="index.php" method="POST">
<td><a href="index.php?controlador=Aulas&accion=listar"><img src="botones/atras.png" width="30px" height="30px"></a></td>
<input type="hidden" name=controlador value=Aulas>
<input type="hidden" name=accion value=gravar_nova>
<table>
    <tr>
        <td><label for="id">ID:</label></td>
        <td><input type="text" name="id" id="id"></td>
    </tr>
    <tr>
        <td><label for="nom">Nom:</label></td>
        <td><input type="text" name="nom" id="nom"></td>
    </tr>
    <tr>
        <td><label for="capacitat">Capacitat:</label></td>
        <td><input type="text" name="capacitat" id="capacitat"></td>
    </tr>
</table>
<input type="submit" value="Gravar dades">
</form>
</body>
</html>




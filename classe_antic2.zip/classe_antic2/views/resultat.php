<?php

print_r($consulta);

?><div class="añadir">
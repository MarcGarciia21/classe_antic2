<?php
$config = Config::singleton();
 
$config->set('controllersFolder', 'controllers/');
$config->set('modelsFolder', 'models/');
$config->set('viewsFolder', 'views/');
 
$config->set('dbhost', 'localhost');
$config->set('dbname', 'escola');
$config->set('dbuser', 'daw_user');
$config->set('dbpass', 'P@ssw0rd');
?>
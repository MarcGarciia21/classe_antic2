<?php
//Incluimos el FrontController
require 'libs/FrontController.php';
//Lo iniciamos con su método estático main.
FrontController::main();
?>
